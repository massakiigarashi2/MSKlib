from setuptools import setup

setup(
    name = 'MSKlib3',
    version = '3.0',
    author = 'Massaki Igarashi',
    author_email = 'prof.massaki@gmail.com',
    packages = ['MSKlib3'],
    description = 'Biblioteca teste desenvolvida pelo Prof. Me. Massaki',
    long_description = 'Um simples arquivo com funções e operações básicas: soma, sub, mult, div'
                        + 'Exemplo de uso:'
                        + 'soma(x,y)'
                        + ' sub(x,y)'
                        + 'mult(x,y)'
                        + ' div(x,y)',
    url = 'https://github.com/massakiigarashi2/MSKlib',
    project_urls = {
        'Código fonte': 'https://github.com/massakiigarashi2/MSKlib',
        'Download': 'https://github.com/massakiigarashi2/aluratempMSK2024/archive/1.0.0.zip'},
    license = 'MIT',
    keywords = 'conversor temperatura alura',
    classifiers = [
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Natural Language :: Portuguese (Brazilian)',
        'Operating System :: OS Independent',
        'Topic :: Software Development :: Internationalization',
        'Topic :: Scientific/Engineering :: Physics']
)